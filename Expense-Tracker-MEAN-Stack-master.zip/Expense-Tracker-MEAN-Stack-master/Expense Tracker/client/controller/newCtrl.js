
angular.module('routerApp').controller('newCtrl',
  ['$http','$scope', '$location','$timeout','$filter',
  function ($http,$scope,$state,$stateParams) {
	  
$scope.category=[];
var refresh=function(){
	$http.get('/user/category').success(function(response){
		$scope.category=response;
	})
}
refresh();
$scope.success=false;
$scope.user={};
var day = new Date();
var month=(day.getMonth()+1)<10?"0"+(day.getMonth()+1).toString():(day.getMonth()+1).toString();
var d=day.getDate()<10?"0"+day.getDate().toString():day.getDate().toString();
$scope.today=day.getFullYear().toString()+"-"+month+"-"+d;

$scope.formData = {};
    
    $scope.formData.selectedCategory = {};
    
    $scope.someSelected = function (object) {
      return Object.keys(object).some(function (key) {
        return object[key];
      });
    }


$scope.submitForm= function(isValid){
	if(isValid){
		var d=$scope.user.date.split('-');
		var dateNow=new Date();
		$scope.user.timestamp=dateNow;
		$scope.user.year=parseInt(d[0]);
		$scope.user.month=parseInt(d[1]);
		$scope.user.day=parseInt(d[2]);
		delete $scope.user.date;
		$scope.user.category=[];	
		for (var k in $scope.formData.selectedCategory) {
			if ($scope.formData.selectedCategory.hasOwnProperty(k)) {
				var cat={};
			    cat['name'] = k;
				cat['amount']=$scope.user.amount;
				cat['year']=parseInt(d[0]);
				cat['month']=parseInt(d[1]);
				cat['day']=parseInt(d[2]);
				cat['timestamp']=dateNow;
			   console.log(cat);
			   $scope.user.category.push(cat);
			}
		}
		
		
		
		$http.post('/user/expenses',$scope.user).success(function(response){
			$scope.success=true;
		});
		
		$scope.formData.selectedCategory={};
		$scope.user={};
		
	}
}

}]);